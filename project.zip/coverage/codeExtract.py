import os
import chardet
import pandas as pd

def detect_encoding(file_path):
    # 使用 chardet 检测文件编码
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read())
    return result['encoding']

def process_file(input_folder, output_folder, search_string):
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(".txt"):
            file_path = os.path.join(input_folder, filename)

            # 检测文件编码
            encoding = detect_encoding(file_path)

            try:
                # 读取文件内容
                with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                    content = f.readlines()

                # 查找包含特定字符串的行
                matching_lines = [line for line in content if search_string in line]

                if matching_lines:
                    # 保存匹配的行到新文件
                    output_file_path = os.path.join(output_folder, filename)
                    with open(output_file_path, 'w', encoding=encoding, errors='ignore') as f:
                        f.writelines(matching_lines)
                    print(f"Processed {filename} and saved matching lines to {output_file_path}")
                else:
                    print(f"{filename} does not contain the specified string. Skipped.")

            except Exception as e:
                print(f"Error processing {filename}: {e}")


if __name__ == "__main__":
    # 输入文件夹和输出文件夹路径
    # D:\实验数据\覆盖率\complex\\txt\CSAFuzzer\\res2
    # D:\实验数据\覆盖率\complex\\txt\CSAFuzzer\\res2\\txt%
    input_folder_path = "D:\实验数据\覆盖率\simple\\txt\oyente\\res1"
    output_folder_path = "D:\实验数据\覆盖率\simple\\txt\oyente\\res1\\txt%"

    # 要搜索的特定字符串, 注意oyente与orisis不一样
    # oyente
    search_string = "INFO:symExec:	  EVM Code Coverage:"
    # orisis
    # search_string = "INFO:symExec:	  EVM code coverage:"
    # mytool
    # search_string = "Total code coverage:"


    # 处理文件
    process_file(input_folder_path, output_folder_path, search_string)





