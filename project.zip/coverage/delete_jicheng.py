import os


def delete_files_with_is(folder_path):
    # 遍历文件夹中的每个文件
    for filename in os.listdir(folder_path):
        if filename.endswith('.sol'):
            file_path = os.path.join(folder_path, filename)

            # 读取文件的第一行
            with open(file_path, 'r', encoding='utf-8') as file:
                first_line = file.readline().strip()

            # 检查第一行是否包含 'is'
            if 'is' in first_line:
                print(f'Deleting file: {file_path}')
                os.remove(file_path)


if __name__ == "__main__":
    folder_path = 'D:\complexdata\end大小簇合约\sFuzz已改名\处理结果--1\\new_contracts\end_small\\2'  # 替换为你的文件夹路径
    delete_files_with_is(folder_path)
