import os
import shutil
import pandas as pd
import re
# 把覆盖率转成Excel表格
# 源文件夹：D:\实验数据\覆盖率\complex\txt\CSAFuzzer\res1\txt%
# 目标文件夹：D:\实验数据\覆盖率\complex\txt\CSAFuzzer\res1\toexecl
def extract_numbers(text):
    # 使用正则表达式提取数字
    return re.findall(r'\b\d+\.\d+%?\b', text)

def txt_numbers_to_excel(input_folder, output_folder):
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(".txt"):
            file_path = os.path.join(input_folder, filename)

            try:
                # 读取 txt 文件内容
                with open(file_path, 'r') as f:
                    content = f.read()

                # 提取数字
                numbers = extract_numbers(content)

                # 创建 DataFrame
                df = pd.DataFrame(numbers, columns=['Numbers'])

                # 将 DataFrame 写入 Excel 文件
                output_file_path = os.path.join(output_folder, filename.replace(".txt", "_numbers.xlsx"))
                df.to_excel(output_file_path, index=False)
                print(f"Processed {filename} and saved to {output_file_path}")

            except Exception as e:
                print(f"Error processing {filename}: {e}")


# 把提取转化完成的txt文件分到不同的文件夹中，一个文件夹里100个

# 表格的目录D:\实验数据\覆盖率\complex\txt\CSAFuzzer\res1\toexecl
# 要存放目录D:\实验数据\覆盖率\complex\Excel\CSAFuzzer
def distribute_files(source_folder, target_parent_folder, num_folders=12):
    # 获取源文件夹下的所有文件
    all_files = os.listdir(source_folder)

    # 计算每个文件夹应该分得的文件数量
    files_per_folder = len(all_files) // num_folders

    # 创建目标文件夹
    target_folders = [os.path.join(target_parent_folder, f"codexlsx_{i + 1}") for i in range(num_folders)]
    for folder in target_folders:
        os.makedirs(folder, exist_ok=True)

    # 开始分配文件
    for i, target_folder in enumerate(target_folders):
        # 计算当前文件夹的起始和结束索引
        start_index = i * files_per_folder
        end_index = start_index + files_per_folder if i < num_folders - 1 else len(all_files)

        # 获取当前文件夹应该分得的文件列表
        files_to_move = all_files[start_index:end_index]

        # 移动文件到目标文件夹
        for file_name in files_to_move:
            if file_name.endswith('.xlsx'):

                source_path = os.path.join(source_folder, file_name)
                target_path = os.path.join(target_folder, file_name)
                shutil.move(source_path, target_path)

    print("文件分配完成！")



def merge(parent_folder, mergexlsx):
    # 遍历总文件夹下的所有子文件夹
    for subdir, _, _ in os.walk(parent_folder):
        # 获取当前子文件夹路径
        subdir_path = os.path.abspath(subdir)
        # print("Reading file:", subdir_path)

        # 获取当前子文件夹中的所有 .xlsx 文件 getexcel
        xlsx_files = [file for file in os.listdir(subdir_path) if file.endswith('.xlsx')]
        # print("Reading content:", xlsx_files)
        if xlsx_files:
            merged_data = pd.DataFrame()
            # 创建一个空的 DataFrame 用于存储合并后的数据

            # 遍历当前子文件夹中的每个 .xlsx 文件
            for file in xlsx_files:
                file_path = os.path.join(subdir_path, file)
                # print("Reading file:", file_path)
                # print("遍历成功")
                df = pd.read_excel(file_path)  # 读取 Excel 文件数据
                # print("读取成功")
                column_name = os.path.splitext(file)[0]  # 使用文件名作为列名
                merged_data[column_name] = df.iloc[:, 0]  # 将数据添加到 DataFrame 的新列

            # 生成输出文件路径
            output_file = os.path.join(mergexlsx, os.path.basename(subdir) + '_merged.xlsx')

            # 将合并后的数据保存到新的 Excel 文件
            merged_data.to_excel(output_file, index=False)

        else:
            continue

if __name__ == "__main__":
    # 输入文件夹和输出文件夹路径
    input_folder_path = "D:\实验数据\覆盖率\simple\\txt\oyente\\res1\\txt%"
    output_folder_path = "D:\实验数据\覆盖率\simple\\txt\oyente\\res1\\txt%\\toexcel"

    # 转换文件
    txt_numbers_to_excel(input_folder_path, output_folder_path)

    wait = "D:\实验数据\覆盖率\simple\\txt\oyente\\res1\\txt%\\toexcel"
    distribution_result = "D:\实验数据\覆盖率\simple\excel\oyente\\res1"
    distribute_files(wait, distribution_result, num_folders=12)
    print("正在合并表格")
    getxlsx_path = "D:\实验数据\覆盖率\simple\excel\oyente\\res1"
    mergexlsx_path = "D:\实验数据\覆盖率\simple\excel\oyente\merge\\res1"
    # # 汇总表格
    merge(getxlsx_path, mergexlsx_path)
    print("合并已完成")
