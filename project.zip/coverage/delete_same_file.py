import os

# 定义文件夹路径
folder1 = r'D:\complexdata\instrusctiondata\end\end_big\1'  # 替换为你的文件夹1路径
folder2 = r'D:\complexdata\instrusctiondata\end\end_big\2'  # 替换为你的文件夹2路径

# 获取两个文件夹中的文件名集合（不包括扩展名）
files_in_folder1 = set(os.path.splitext(file)[0] for file in os.listdir(folder1))
files_in_folder2 = set(os.path.splitext(file)[0] for file in os.listdir(folder2))

# 找到相同的文件名
common_files = files_in_folder1.intersection(files_in_folder2)

# 遍历文件夹1，删除与文件夹2中相同文件名的文件
for file in os.listdir(folder1):
    file_name_without_ext = os.path.splitext(file)[0]
    if file_name_without_ext in common_files:
        file_path = os.path.join(folder1, file)
        os.remove(file_path)
        print(f"删除文件: {file_path}")

print("相同文件名的文件删除完成。")
