import os
import re
import pandas as pd

# 定义文件夹路径
txt_folder = r'D:\complexdata\覆盖率最终结果\small\txt\2'  # 替换为你的txt文件夹路径
output_folder = r'D:\complexdata\覆盖率最终结果\small\excel\2'  # 替换为你的输出文件夹路径

# 如果输出文件夹不存在，则创建
os.makedirs(output_folder, exist_ok=True)

# 正则表达式，用于提取Branch coverage和Time
pattern = r'Code coverage: ([\d.]+%) .* Time: ([\d.]+)'

# 遍历文件夹中的所有txt文件
for txt_file in os.listdir(txt_folder):
    if txt_file.endswith('.txt'):
        txt_file_path = os.path.join(txt_folder, txt_file)
        data = []

        # 读取txt文件并提取数据
        with open(txt_file_path, 'r', encoding='utf-8') as file:
            for line in file:
                match = re.search(pattern, line)
                if match:
                    branch_coverage = match.group(1)
                    time = match.group(2)
                    # 获取文件名（不带后缀）
                    file_name = os.path.splitext(txt_file)[0]
                    data.append([file_name, time, branch_coverage])

        # 创建DataFrame，调整列顺序为Time在前，Branch coverage在后
        df = pd.DataFrame(data, columns=['文件名', 'Time', 'Code coverage'])

        # 输出xlsx文件路径
        output_file = os.path.join(output_folder, f'{file_name}.xlsx')

        # 保存到xlsx
        df.to_excel(output_file, index=False)
        print(f"生成 {output_file} 完成！")

print("所有文件处理完成！")
